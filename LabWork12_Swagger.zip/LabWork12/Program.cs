using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "LabWork12 API",
        Version = "v1",
        Description = "Лабораторная работа №12 — JWT и OAuth через GitHub"
    });

    options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "Вставьте JWT-токен, полученный через POST /auth/login"
    });

    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

var jwtKey = builder.Configuration["Jwt:Key"]
    ?? "LabWork12_DEMO_KEY_ChangeThis_AtLeast32Chars!";
var jwtIssuer = builder.Configuration["Jwt:Issuer"] ?? "LabWork12";
var jwtAudience = builder.Configuration["Jwt:Audience"] ?? "LabWork12Client";
var jwtMinutes = builder.Configuration.GetValue<int?>("Jwt:AccessTokenExpirationMinutes") ?? 60;

const string bearerScheme = JwtBearerDefaults.AuthenticationScheme;
const string cookieScheme = CookieAuthenticationDefaults.AuthenticationScheme;
const string githubScheme = "GitHub";

builder.Services
    .AddAuthentication(options =>
    {
        // Cookie нужен для OAuth-входа через GitHub; JWT используется для API-запросов.
        options.DefaultAuthenticateScheme = cookieScheme;
        options.DefaultSignInScheme = cookieScheme;
        options.DefaultChallengeScheme = githubScheme;
    })
    .AddCookie(cookieScheme, options =>
    {
        options.Cookie.Name = "LabWork12.Auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
    })
    .AddJwtBearer(bearerScheme, options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwtIssuer,
            ValidateAudience = true,
            ValidAudience = jwtAudience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30),
            NameClaimType = ClaimTypes.Name,
            RoleClaimType = ClaimTypes.Role
        };
    })
    .AddOAuth(githubScheme, options =>
    {
        options.ClientId = builder.Configuration["GitHub:ClientId"] ?? "YOUR_GITHUB_CLIENT_ID";
        options.ClientSecret = builder.Configuration["GitHub:ClientSecret"] ?? "YOUR_GITHUB_CLIENT_SECRET";
        options.CallbackPath = "/signin-github";
        options.AuthorizationEndpoint = "https://github.com/login/oauth/authorize";
        options.TokenEndpoint = "https://github.com/login/oauth/access_token";
        options.UserInformationEndpoint = "https://api.github.com/user";
        options.SignInScheme = cookieScheme;
        options.SaveTokens = true;
        options.Scope.Add("read:user");

        options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "id");
        options.ClaimActions.MapJsonKey(ClaimTypes.Name, "login");
        options.ClaimActions.MapJsonKey("urn:github:name", "name");
        options.ClaimActions.MapJsonKey("urn:github:avatar", "avatar_url");

        options.Events = new OAuthEvents
        {
            OnCreatingTicket = async context =>
            {
                using var request = new HttpRequestMessage(
                    HttpMethod.Get, context.Options.UserInformationEndpoint);
                request.Headers.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", context.AccessToken);
                request.Headers.UserAgent.ParseAdd("LabWork12");

                using var response = await context.Backchannel.SendAsync(
                    request, context.HttpContext.RequestAborted);
                response.EnsureSuccessStatusCode();

                using var user = JsonDocument.Parse(await response.Content.ReadAsStringAsync(
                    context.HttpContext.RequestAborted));
                context.RunClaimActions(user.RootElement);
            }
        };
    });

builder.Services.AddAuthorization(options =>
{
    // Эти запросы принимают только JWT, чтобы роли проверялись из токена.
    options.AddPolicy("BearerOnly", policy =>
        policy.AddAuthenticationSchemes(bearerScheme).RequireAuthenticatedUser());

    // Профиль доступен после входа любым из двух способов: JWT или GitHub Cookie.
    options.AddPolicy("Profile", policy =>
        policy.AddAuthenticationSchemes(bearerScheme, cookieScheme).RequireAuthenticatedUser());
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/", () => Results.Ok(new
{
    project = "LabWork12",
    description = "Лабораторная работа №12 — JWT и OAuth (GitHub)",
    endpoints = new[]
    {
        "POST /auth/login",
        "GET /auth/github",
        "GET /profile",
        "GET /api/student",
        "GET /api/teacher"
    }
}));

// Учебные учетные записи. В реальном приложении пароли должны храниться в БД
// только в виде стойких хешей, а не в открытом виде.
var demoUsers = new Dictionary<string, (string Password, string Role)>(StringComparer.OrdinalIgnoreCase)
{
    ["student"] = ("student123", "Student"),
    ["teacher"] = ("teacher123", "Teacher")
};

// 5.1.3: проверка учетных данных и выдача JWT с именем пользователя и ролью.
app.MapPost("/auth/login", (LoginRequest request) =>
{
    if (!demoUsers.TryGetValue(request.Username, out var account) ||
        account.Password != request.Password)
    {
        return Results.Unauthorized();
    }

    var claims = new[]
    {
        new Claim(ClaimTypes.NameIdentifier, request.Username),
        new Claim(ClaimTypes.Name, request.Username),
        new Claim(ClaimTypes.Role, account.Role)
    };

    var credentials = new SigningCredentials(
        new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
        SecurityAlgorithms.HmacSha256);

    var token = new JwtSecurityToken(
        issuer: jwtIssuer,
        audience: jwtAudience,
        claims: claims,
        expires: DateTime.UtcNow.AddMinutes(jwtMinutes),
        signingCredentials: credentials);

    return Results.Ok(new
    {
        access_token = new JwtSecurityTokenHandler().WriteToken(token),
        token_type = "Bearer",
        expires_in_minutes = jwtMinutes,
        username = request.Username,
        role = account.Role
    });
}).AllowAnonymous();

// 5.2.9: запускает OAuth-процесс и после успешного входа возвращает пользователя в /profile.
app.MapGet("/auth/github", async (HttpContext context) =>
{
    await context.ChallengeAsync(githubScheme,
        new AuthenticationProperties { RedirectUri = "/profile" });
}).AllowAnonymous();

// 5.3.3: профиль доступен по JWT или по Cookie, созданной после входа через GitHub.
app.MapGet("/profile", (HttpContext context) =>
{
    var user = context.User;
    return Results.Ok(new
    {
        authenticated = user.Identity?.IsAuthenticated ?? false,
        name = user.Identity?.Name ?? "не указано",
        userId = user.FindFirst(ClaimTypes.NameIdentifier)?.Value,
        role = user.FindFirst(ClaimTypes.Role)?.Value ?? "роль не назначена",
        authenticationType = user.Identity?.AuthenticationType,
        githubName = user.FindFirst("urn:github:name")?.Value,
        avatar = user.FindFirst("urn:github:avatar")?.Value
    });
}).RequireAuthorization("Profile");

// Роль Student имеет доступ только к этому запросу.
app.MapGet("/api/student", (HttpContext context) =>
{
    var name = context.User.Identity?.Name ?? "неизвестно";
    var role = context.User.FindFirst(ClaimTypes.Role)?.Value ?? "неизвестно";
    return Results.Ok(new
    {
        message = "Доступ разрешен: раздел студента.",
        username = name,
        role
    });
}).RequireAuthorization(policy =>
{
    policy.AddAuthenticationSchemes(bearerScheme);
    policy.RequireAuthenticatedUser();
    policy.RequireRole("Student");
});

// Роль Teacher имеет доступ только к этому запросу.
app.MapGet("/api/teacher", (HttpContext context) =>
{
    var name = context.User.Identity?.Name ?? "неизвестно";
    var role = context.User.FindFirst(ClaimTypes.Role)?.Value ?? "неизвестно";
    return Results.Ok(new
    {
        message = "Доступ разрешен: раздел преподавателя.",
        username = name,
        role
    });
}).RequireAuthorization(policy =>
{
    policy.AddAuthenticationSchemes(bearerScheme);
    policy.RequireAuthenticatedUser();
    policy.RequireRole("Teacher");
});

app.Run();

record LoginRequest(string Username, string Password);
