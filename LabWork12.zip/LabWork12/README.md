# LabWork12 — лабораторная работа №12

Тема: изучение методов аутентификации и авторизации в веб-приложениях.

Проект реализует все три пункта задания из методички:
- **5.1 JWT** — вход по логину и паролю, выдача JWT и разграничение доступа по ролям `Student` и `Teacher`.
- **5.2 OAuth GitHub** — вход через GitHub OAuth App с сохранением авторизации в Cookie.
- **5.3 Объединение схем** — `/profile` принимает как JWT, так и Cookie после GitHub OAuth.

## Требования
- .NET 8 SDK
- браузер
- для проверки OAuth — аккаунт GitHub и зарегистрированное OAuth App

## 1. Открыть и запустить проект
Откройте `LabWork12.csproj` в Visual Studio / Rider либо откройте терминал в папке проекта и выполните:

```bash
dotnet restore
dotnet run
```

Приложение запускается по адресу `http://localhost:5000`.

## 2. Проверить JWT

Демонстрационные учетные записи (они предназначены только для лабораторной работы):

| Логин | Пароль | Роль |
|---|---|---|
| student | student123 | Student |
| teacher | teacher123 | Teacher |

Получить токен:

```bash
curl -X POST http://localhost:5000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"student","password":"student123"}'
```

Скопируйте значение `access_token` из ответа. Затем подставьте его вместо `ВАШ_ТОКЕН`:

```bash
curl http://localhost:5000/api/student -H "Authorization: Bearer ВАШ_ТОКЕН"
curl http://localhost:5000/api/teacher -H "Authorization: Bearer ВАШ_ТОКЕН"
curl http://localhost:5000/profile -H "Authorization: Bearer ВАШ_ТОКЕН"
```

Ожидаемый результат:
- токен пользователя `student` открывает `/api/student`;
- тот же токен не открывает `/api/teacher` (ответ 403 Forbidden);
- токен `teacher` открывает `/api/teacher`, но не `/api/student`;
- `/profile` возвращает имя и роль пользователя.

## 3. Зарегистрировать OAuth-приложение GitHub (пункт 9 приложения)

1. Войдите в GitHub.
2. Откройте https://github.com/settings/developers.
3. Выберите **OAuth Apps** → **New OAuth App**.
4. Заполните поля:
   - **Application name:** `LabWork12`
   - **Homepage URL:** `http://localhost:5000`
   - **Authorization callback URL:** `http://localhost:5000/signin-github`
5. Нажмите **Register application**.
6. Скопируйте **Client ID**.
7. Нажмите **Generate a new client secret** и скопируйте **Client Secret**. Не публикуйте его и не отправляйте в Git.
8. В `appsettings.json` замените `YOUR_GITHUB_CLIENT_ID` и `YOUR_GITHUB_CLIENT_SECRET` на полученные значения.

Для локальной демонстрации используется HTTP localhost. Не используйте такой адрес и демонстрационные секреты в публичном развертывании.

## 4. Проверить GitHub OAuth

1. Убедитесь, что приложение запущено.
2. Откройте в браузере `http://localhost:5000/auth/github`.
3. Разрешите приложению доступ к базовой информации GitHub.
4. После успешного входа GitHub перенаправит браузер на `/profile`.
5. На странице `/profile` отобразятся имя пользователя GitHub и доступные сведения. OAuth-вход подтверждает личность, но не присваивает учебные роли `Student`/`Teacher`.

## 5. Проверить объединенную схему

- Войдите через JWT и отправьте запрос на `/profile` с заголовком `Authorization: Bearer ...`.
- Отдельно выполните вход через `/auth/github` и откройте `/profile` в том же браузере: запрос будет авторизован с помощью Cookie.

## Используемые маршруты

| Метод | Маршрут | Назначение |
|---|---|---|
| POST | `/auth/login` | Проверка логина/пароля и выдача JWT |
| GET | `/auth/github` | Начало OAuth-аутентификации GitHub |
| GET | `/profile` | Информация о текущем пользователе (JWT или Cookie) |
| GET | `/api/student` | Только роль Student, JWT |
| GET | `/api/teacher` | Только роль Teacher, JWT |

## Важные замечания
- В проекте используются демонстрационные учетные записи в памяти приложения, чтобы не усложнять учебную работу базой данных.
- В реальной системе пароли хранят в виде хешей, секреты — в Secret Manager / переменных окружения, а JWT-ключ не размещают в исходниках.
- Для OAuth callback путь `/signin-github` должен в точности совпадать с URL, указанным в настройках GitHub.
